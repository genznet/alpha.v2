from kyt import *
import subprocess
from telethon import events
from telethon.tl.custom import Button

# (Pastikan DOMAIN dan valid() sudah ada di 'kyt.py' atau di atas)

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" MENU SSH OVPN","ssh")],
[Button.inline(" MENU VMESS","vmess"),
Button.inline(" MENU VLESS ","vless")],
[Button.inline(" MENU TROJAN","trojan"),
Button.inline(" MENU SHDWSK ","shadowsocks")],
[Button.inline(" CHECK SERVICE ","info"),
Button.inline(" OTHER SETTING ","setting")],
[Button.inline(" ‹ Back Menu › ","start")]]
	
	sender = await event.get_sender()
	val = valid(str(sender.id))
	
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		
		# --- [PERBAIKAN] Menggunakan perintah yang sama dengan script 'menu' VPS ---

		# 1. Perintah untuk SSH (dari /etc/passwd)
		sh_cmd = f"awk -F: '$3 >= 1000 && $1 != \"nobody\" {{print $1}}' /etc/passwd | wc -l"
		ssh = subprocess.check_output(sh_cmd, shell=True).decode("ascii")

		# 2. Perintah untuk VMESS (dari config.json dan dibagi 2)
		vm_cmd = f'vmc=$(grep -c -E "^### " "/etc/xray/config.json"); echo $((vmc / 2))'
		vms = subprocess.check_output(vm_cmd, shell=True).decode("ascii")

		# 3. Perintah untuk VLESS (dari config.json dan dibagi 2)
		vl_cmd = f'vlx=$(grep -c -E "^#& " "/etc/xray/config.json"); echo $((vlx / 2))'
		vls = subprocess.check_output(vl_cmd, shell=True).decode("ascii")

		# 4. Perintah untuk TROJAN (dari config.json dan dibagi 2)
		tr_cmd = f'trx=$(grep -c -E "^#! " "/etc/xray/config.json"); echo $((trx / 2))'
		trj = subprocess.check_output(tr_cmd, shell=True).decode("ascii")

		# 5. Perintah untuk OS (menghapus tanda kutip)
		os_cmd = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g' | sed 's/\"//g'"
		namaos = subprocess.check_output(os_cmd, shell=True).decode("ascii")

		# 6. Perintah untuk IP VPS
		ipvps = f"curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

		# 7. Perintah untuk City (menggunakan path dari script VPS)
		city_cmd = f"cat /root/.info/.city"
		city = subprocess.check_output(city_cmd, shell=True).decode("ascii")

		# --- Akhir dari Perbaikan ---

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
 **⚠️ ADMIN PANEL MENU ⚠️**
━━━━━━━━━━━━━━━━━━━━━━━
**» OS      :** `{namaos.strip()}`
**» CITY    :** `{city.strip()}`
**» DOMAIN  :** `{DOMAIN}`
**» IP VPS  :** `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**» 🟢SSH OVPN    :** `{ssh.strip()}` __account__
**» 🟢XRAY VMESS  :** `{vms.strip()}` __account__
**» 🟢XRAY VLESS  :** `{vls.strip()}` __account__
**» 🟢XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		
		# Coba 'edit' dulu, kalau gagal (misal dari /menu), baru 'reply'
		try:
			await event.edit(msg, buttons=inline)
		except Exception:
			await event.reply(msg, buttons=inline)